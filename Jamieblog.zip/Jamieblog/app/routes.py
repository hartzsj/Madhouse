from flask import render_template
from app import app
import requests

@app.route('/')

@app.route('/index')
def index():
    user = {'username': 'Jamie'}
    url = "http://jamie.cn"
    response = requests.get(url)
    weibo = response.text
    return render_template('index.html', title='Jamie', user=user ,post=weibo)
